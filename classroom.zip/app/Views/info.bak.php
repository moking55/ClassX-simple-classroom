<div class="info-bg d-flex justify-content-center" style="min-height: 92.6vh">
    <div class="my-auto">
        <div class="container">
            <div class="row text-center py-4 gy-3">
                <div class="col-md-12">
                    <h3>เขียนและจัดจำหน่ายโดย</h3>
                </div>
                <div class="col-md-12">
                    <img src="/img/profile/6404101332.jpg" style="height: 140px" alt="6404101332">
                    <h5 class="m-0">นายเมธาวัฒน์ มหาวัน</h5>
                    <p class="m-0">6404101332</p>
                </div>
                <div class="col-md-6">
                    <img src="/img/profile/6404101332.jpg" style="height: 140px" alt="6404101332">
                    <h5 class="m-0">นายเมธาวัฒน์ มหาวัน</h5>
                    <p class="m-0">6404101332</p>
                </div>
                <div class="col-md-6">
                    <img src="/img/profile/6404101332.jpg" style="height: 140px" alt="6404101332">
                    <h5 class="m-0">นายเมธาวัฒน์ มหาวัน</h5>
                    <p class="m-0">6404101332</p>
                </div>
                <div class="col-md-6">
                    <img src="/img/profile/6404101332.jpg" style="height: 140px" alt="6404101332">
                    <h5 class="m-0">นายเมธาวัฒน์ มหาวัน</h5>
                    <p class="m-0">6404101332</p>
                </div>
                <div class="col-md-6">
                    <img src="/img/profile/6404101332.jpg" style="height: 140px" alt="6404101332">
                    <h5 class="m-0">นายเมธาวัฒน์ มหาวัน</h5>
                    <p class="m-0">6404101332</p>
                </div>
            </div>
        </div>
    </div>
</div>